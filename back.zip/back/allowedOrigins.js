export const allowedOrigins = [
  "http://localhost:3000",
  "https://savefrom.in",
  "https://www.savefrom.in",
  "https://api.savefrom.in"
];
